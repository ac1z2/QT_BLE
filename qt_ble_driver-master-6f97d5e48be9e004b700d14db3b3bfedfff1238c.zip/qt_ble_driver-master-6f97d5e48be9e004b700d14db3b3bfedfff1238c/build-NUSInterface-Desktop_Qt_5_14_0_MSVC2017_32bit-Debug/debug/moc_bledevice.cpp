/****************************************************************************
** Meta object code from reading C++ file 'bledevice.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../code/bledevice.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bledevice.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_BLEDevice_t {
    QByteArrayData data[20];
    char stringdata0[240];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BLEDevice_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BLEDevice_t qt_meta_stringdata_BLEDevice = {
    {
QT_MOC_LITERAL(0, 0, 9), // "BLEDevice"
QT_MOC_LITERAL(1, 10, 11), // "nameChanged"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 15), // "servicesChanged"
QT_MOC_LITERAL(4, 39, 23), // "servicesCompleteChanged"
QT_MOC_LITERAL(5, 63, 12), // "stateChanged"
QT_MOC_LITERAL(6, 76, 19), // "establishConnection"
QT_MOC_LITERAL(7, 96, 17), // "serviceDiscovered"
QT_MOC_LITERAL(8, 114, 14), // "QBluetoothUuid"
QT_MOC_LITERAL(9, 129, 7), // "service"
QT_MOC_LITERAL(10, 137, 15), // "serviceScanDone"
QT_MOC_LITERAL(11, 153, 4), // "name"
QT_MOC_LITERAL(12, 158, 7), // "address"
QT_MOC_LITERAL(13, 166, 16), // "servicesComplete"
QT_MOC_LITERAL(14, 183, 5), // "State"
QT_MOC_LITERAL(15, 189, 10), // "Discovered"
QT_MOC_LITERAL(16, 200, 10), // "Connecting"
QT_MOC_LITERAL(17, 211, 9), // "Connected"
QT_MOC_LITERAL(18, 221, 12), // "Disconnected"
QT_MOC_LITERAL(19, 234, 5) // "Error"

    },
    "BLEDevice\0nameChanged\0\0servicesChanged\0"
    "servicesCompleteChanged\0stateChanged\0"
    "establishConnection\0serviceDiscovered\0"
    "QBluetoothUuid\0service\0serviceScanDone\0"
    "name\0address\0servicesComplete\0State\0"
    "Discovered\0Connecting\0Connected\0"
    "Disconnected\0Error"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BLEDevice[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       3,   58, // properties
       1,   70, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x06 /* Public */,
       3,    0,   50,    2, 0x06 /* Public */,
       4,    0,   51,    2, 0x06 /* Public */,
       5,    0,   52,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,   53,    2, 0x0a /* Public */,
       7,    1,   54,    2, 0x08 /* Private */,
      10,    0,   57,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,

 // properties: name, type, flags
      11, QMetaType::QString, 0x00495001,
      12, QMetaType::QString, 0x00095001,
      13, QMetaType::Bool, 0x00495001,

 // properties: notify_signal_id
       0,
       0,
       2,

 // enums: name, alias, flags, count, data
      14,   14, 0x0,    5,   75,

 // enum data: key, value
      15, uint(BLEDevice::Discovered),
      16, uint(BLEDevice::Connecting),
      17, uint(BLEDevice::Connected),
      18, uint(BLEDevice::Disconnected),
      19, uint(BLEDevice::Error),

       0        // eod
};

void BLEDevice::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BLEDevice *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->nameChanged(); break;
        case 1: _t->servicesChanged(); break;
        case 2: _t->servicesCompleteChanged(); break;
        case 3: _t->stateChanged(); break;
        case 4: _t->establishConnection(); break;
        case 5: _t->serviceDiscovered((*reinterpret_cast< const QBluetoothUuid(*)>(_a[1]))); break;
        case 6: _t->serviceScanDone(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QBluetoothUuid >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (BLEDevice::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEDevice::nameChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (BLEDevice::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEDevice::servicesChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (BLEDevice::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEDevice::servicesCompleteChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (BLEDevice::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&BLEDevice::stateChanged)) {
                *result = 3;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<BLEDevice *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->name(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->address(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->servicesComplete(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject BLEDevice::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_BLEDevice.data,
    qt_meta_data_BLEDevice,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *BLEDevice::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BLEDevice::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_BLEDevice.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int BLEDevice::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void BLEDevice::nameChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void BLEDevice::servicesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void BLEDevice::servicesCompleteChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void BLEDevice::stateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
