/****************************************************************************
** Meta object code from reading C++ file 'uartservice.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../code/uartservice.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'uartservice.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_UARTService_t {
    QByteArrayData data[25];
    char stringdata0[285];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UARTService_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UARTService_t qt_meta_stringdata_UARTService = {
    {
QT_MOC_LITERAL(0, 0, 11), // "UARTService"
QT_MOC_LITERAL(1, 12, 12), // "stateChanged"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 2), // "rx"
QT_MOC_LITERAL(4, 29, 1), // "s"
QT_MOC_LITERAL(5, 31, 5), // "rxbin"
QT_MOC_LITERAL(6, 37, 5), // "bytes"
QT_MOC_LITERAL(7, 43, 2), // "tx"
QT_MOC_LITERAL(8, 46, 3), // "str"
QT_MOC_LITERAL(9, 50, 5), // "txbin"
QT_MOC_LITERAL(10, 56, 20), // "onDeviceStateChanged"
QT_MOC_LITERAL(11, 77, 19), // "serviceStateChanged"
QT_MOC_LITERAL(12, 97, 31), // "QLowEnergyService::ServiceState"
QT_MOC_LITERAL(13, 129, 5), // "state"
QT_MOC_LITERAL(14, 135, 28), // "serviceCharacteristicChanged"
QT_MOC_LITERAL(15, 164, 24), // "QLowEnergyCharacteristic"
QT_MOC_LITERAL(16, 189, 14), // "characteristic"
QT_MOC_LITERAL(17, 204, 5), // "value"
QT_MOC_LITERAL(18, 210, 28), // "serviceCharacteristicWritten"
QT_MOC_LITERAL(19, 239, 9), // "setDevice"
QT_MOC_LITERAL(20, 249, 6), // "device"
QT_MOC_LITERAL(21, 256, 5), // "State"
QT_MOC_LITERAL(22, 262, 11), // "DEVICE_WAIT"
QT_MOC_LITERAL(23, 274, 4), // "INIT"
QT_MOC_LITERAL(24, 279, 5) // "READY"

    },
    "UARTService\0stateChanged\0\0rx\0s\0rxbin\0"
    "bytes\0tx\0str\0txbin\0onDeviceStateChanged\0"
    "serviceStateChanged\0QLowEnergyService::ServiceState\0"
    "state\0serviceCharacteristicChanged\0"
    "QLowEnergyCharacteristic\0characteristic\0"
    "value\0serviceCharacteristicWritten\0"
    "setDevice\0device\0State\0DEVICE_WAIT\0"
    "INIT\0READY"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UARTService[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       1,   94, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x06 /* Public */,
       3,    1,   65,    2, 0x06 /* Public */,
       5,    1,   68,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   71,    2, 0x0a /* Public */,
       9,    1,   74,    2, 0x0a /* Public */,
      10,    0,   77,    2, 0x08 /* Private */,
      11,    1,   78,    2, 0x08 /* Private */,
      14,    2,   81,    2, 0x08 /* Private */,
      18,    2,   86,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
      19,    1,   91,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QByteArray,    6,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QByteArray,    6,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QByteArray,   16,   17,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QByteArray,   16,   17,

 // methods: parameters
    QMetaType::Void, QMetaType::QObjectStar,   20,

 // enums: name, alias, flags, count, data
      21,   21, 0x0,    3,   99,

 // enum data: key, value
      22, uint(UARTService::DEVICE_WAIT),
      23, uint(UARTService::INIT),
      24, uint(UARTService::READY),

       0        // eod
};

void UARTService::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UARTService *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->stateChanged(); break;
        case 1: _t->rx((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->rxbin((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 3: _t->tx((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->txbin((*reinterpret_cast< const QByteArray(*)>(_a[1]))); break;
        case 5: _t->onDeviceStateChanged(); break;
        case 6: _t->serviceStateChanged((*reinterpret_cast< const QLowEnergyService::ServiceState(*)>(_a[1]))); break;
        case 7: _t->serviceCharacteristicChanged((*reinterpret_cast< const QLowEnergyCharacteristic(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 8: _t->serviceCharacteristicWritten((*reinterpret_cast< const QLowEnergyCharacteristic(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 9: _t->setDevice((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyService::ServiceState >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyCharacteristic >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QLowEnergyCharacteristic >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UARTService::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UARTService::stateChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (UARTService::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UARTService::rx)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (UARTService::*)(const QByteArray & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UARTService::rxbin)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject UARTService::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_UARTService.data,
    qt_meta_data_UARTService,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *UARTService::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UARTService::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_UARTService.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int UARTService::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void UARTService::stateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void UARTService::rx(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void UARTService::rxbin(const QByteArray & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
